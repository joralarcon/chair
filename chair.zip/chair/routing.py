import cv2
import numpy as np
import scipy as sci
from matplotlib import pyplot as plt


#load map
map1 = cv2.imread("MAP.png",1)

cv2.imshow("map",map1)
#define areas
#lab1 (250,90) (460,200)
x = (460-250)/2 + 250
y = (200-90)/2 + 200
lab1 = (x,y)
#exit1lab1 (300,200) (330,210)
x = (330-300)/2 + 300
y = (210-200)/2 + 200
exit1lab1 = (x,y)
#exit2lab1 (440,200) (460,210)
x = (460-440)/2 + 440
y = (210-200)/2 + 200
exit2lab1 = (x,y)

#lab2 (250,330) (460,430)
x = (460-250)/2 + 250
y = (430-330)/2 + 330
lab2 = (x,y)
#exit1lab2 (320,320) (340,330)
x = (340-320)/2 + 320
y = (330-320)/2 + 320
exit1lab2 = (x,y)
#exit2lab2 (420,320) (440,330)
x = (440-420)/2 + 420
y = (330-320)/2 + 320
exit2lab2 = (x,y)

#advising area (70,70) (230,220)
x = (230-70)/2 + 70
y = (220-70)/2 + 70
adv = (x,y)
#advent (230,190) (240,220)
x = (240-230)/2 + 230
y = (220-190)/2 + 190
advent = (x,y)

#mech (100,220) (230,390)
x = (230-100)/2 + 100
y = (390-220)/2 + 220
mech = (x,y)
#mechent (230,230) (240,300)
x = (240-230)/2 + 230
y = (300-230)/2 + 230
mechent = (x,y)

#points to avoid walls
p1 = (380, 260)
p2 = (255, 275)
p3 = (255,205)

#routing algorithm




cv2.waitKey(0)

