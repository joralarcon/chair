#!/usr/bin/python
 
import spidev
import time
import os
import sys
 
# Open SPI bus
spi = spidev.SpiDev()
spi.open(0,0)
 
# Function to read SPI data from MCP3008 chip
# Channel must be an integer 0-7
def ReadChannel(channel):
  adc = spi.xfer2([1,(8+channel)<<4,0])
  data = ((adc[1]&3) << 8) + adc[2]
  return data
 
# Function to convert data to voltage level,
# rounded to specified number of decimal places.
def ConvertVolts(data,places):
  volts = (data * 3.3) / float(1023)
  volts = round(volts,places)
  return volts
 
# Function to calculate temperature from
# TMP36 data, rounded to specified
# number of decimal places.
def ConvertDist(volt,places):
 
  dist = 27/volt
  dist = round(dist,places)
  return dist
 
# Define sensor channels
dist_channel  = 1
 
# Define delay between readings
delay = .5
 
while True:
 
  # Read the distance sensor data
  dist_data = ReadChannel(dist_channel)
  dist_volts = ConvertVolts(dist_data,2)
  dist = ConvertDist(dist_volts,2)
 
  # Print out results
  print "--------------------------------------------"
  print("Distance : {} cm".format(dist))

  if dist >= 30.00:
      print('SAFE')
  elif dist >= 15.00:
      print('......OBJECT GETTING CLOSER.......')
  else:
      print('!!!!!!!!WARNING TO CLOSE!!!!!!!!')
      sys.exit(0)
 
# Wait before repeating loop
  time.sleep(delay)

