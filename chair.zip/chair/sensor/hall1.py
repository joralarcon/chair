# Import required libraries
import RPi.GPIO as GPIO
import time
import datetime
from collections import Counter

def leftSensor(channel):
  # Called if sensor reads LOW
  timestamp = time.time()
  sec = datetime.datetime.fromtimestamp(timestamp).strftime('%S') #seconds
  print "LOW " + sec

def main():
  try:
    # Loop until users quits with CTRL-C
    while True :
      time.sleep(0.1)

  except KeyboardInterrupt:
    # Reset GPIO settings
    GPIO.cleanup()  
  
# Tell GPIO library to use GPIO references
GPIO.setmode(GPIO.BCM)

#for reference initialization
print "Start" 

# Set Switch GPIO as input
GPIO.setup(17, GPIO.IN)
# When mangent passes ----- LOW
GPIO.add_event_detect(17, GPIO.FALLING, callback=leftSensor)

if __name__=="__main__":
   main()
sensor = [leftSensor]
sensor_counts = Counter(sensor)

