import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(25, GPIO.OUT)


p2 = GPIO.PWM(25,500)

p2.start(75)

try:
    while True:
           p2.ChangeDutyCycle(75)
           time.sleep(1)
           print("oneside") 
           p2.ChangeDutyCycle(100)
           time.sleep(1)
           print("anotherside")
           p2.ChangeDutyCycle(50)
           time.sleep(1)
           print("justtheside")

except KeyboardInterrupt:
    GPIO.cleanup()
            

  
  
 
    
