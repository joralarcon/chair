#!/usr/bin/python3
import RPi.GPIO as GPIO
from time import sleep
import time, math

dist_meas = 0.00
mi_per_hour = 0
rpm = 0
elapse = 0
sensor = 17 #pin sensor
pulse = 0
start_timer = time.time()

def init_GPIO():               # initialize GPIO
   GPIO.setmode(GPIO.BCM)
   GPIO.setwarnings(False)
   GPIO.setup(sensor,GPIO.IN,GPIO.PUD_UP)

def calculate_elapse(channel):            # callback function
   global pulse, start_timer, elapse
   pulse+=1                        # increase pulse by 1 whenever interrupt occurred
   elapse = time.time() - start_timer      # elapse for every 1 complete rotation made!
   start_timer = time.time()            # let current time equals to start_timer

def calculate_speed(r_in):
   global pulse,elapse,rpm,dist_mi,dist_meas,mi_per_sec,mi_per_hour
   if elapse !=0:                     # to avoid DivisionByZero error
      rpm = 1/elapse * 60
      circ_in = (2*math.pi)*r_in / 3  # calculate wheel circumference split in 9 INCHES
      dist_mi = circ_in/63360         # convert in to mi
      mi_per_sec = dist_mi / elapse      # calculate Mi/sec
      mi_per_hour = mi_per_sec * 3600      # calculate MPH
      dist_meas = (dist_mi*pulse)*5280   # measure distance traverse in feet
      return mi_per_hour

def init_interrupt():
   GPIO.add_event_detect(sensor, GPIO.FALLING, callback = calculate_elapse, bouncetime = 20)

if __name__ == '__main__':
   init_GPIO()
   init_interrupt()
   while True:
      calculate_speed(12)   # call this function with wheel radius as parameter
      print('mi_per_hour:{0:.0f}MPH pulse:{1}'.format(mi_per_hour,pulse))
      #print('rpm:{0:.0f}RPM mi_per_hour:{1:.1f}MPH dist_meas:{2:.2f}ft pulse:{3}'.format(rpm,mi_per_hour,dist_meas,pulse))
      sleep(0.1)

