import RPi.GPIO as GPIO # import GPIO librery

from time import sleep
import time

GPIO.setmode(GPIO.BCM)


Motor1A = 24 # set GPIO-02 as Input 1 of the controller IC
Motor1B = 25 # set GPIO-03 as Input 2 of the controller IC
Motor1E = 21 # set GPIO-04 as Enable pin 1 of the controller IC



GPIO.setup(Motor1A,GPIO.OUT)

GPIO.setup(Motor1B,GPIO.OUT)

GPIO.setup(Motor1E,GPIO.OUT)



20 pwm 
24 for tigrrer



pwm=GPIO.PWM(21,1000) # configuring Enable pin means GPIO-04 for PWM

pwm.start(0)




for dc in range  (0, 50, 1):
         pwm.ChangeDutyCycle(dc)
         time.sleep(.05)
         print(dc)
for dc in range (50, 0, -1):
         pwm.ChangeDutyCycle(dc)
         time.sleep(.05)
         print "GO forward"

GPIO.output(Motor1A,GPIO.HIGH)

GPIO.output(Motor1B,GPIO.LOW)

GPIO.output(Motor1E,GPIO.HIGH)

sleep(2)


for dc in range  (0, 50, 1):
        pwm.ChangeDutyCycle(dc)
        time.sleep(0.05)
        print(dc)
for dc in range (50, 0, -1):
        pwm.ChangeDutyCycle(dc)
        time.sleep(0.05)
        print "GO backward"


# this will run your motor in forward direction for 2 seconds with 50% speed.

#pwm.ChangeDutyCycle(10) # increasing dutycycle to 80

print "good job"

GPIO.output(Motor1A,GPIO.LOW)

GPIO.output(Motor1B,GPIO.HIGH)

GPIO.output(Motor1E,GPIO.HIGH)

sleep(2)

# this will run your motor in reverse direction for 2 seconds with 80% speed by supplying 80% of the battery voltage

print "Now stop"




pwm.stop() # stop PWM from GPIO output it is necessary
GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(Motor1E,GPIO.OUT)
GPIO.output(Motor1E,GPIO.LOW)
GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(Motor1A,GPIO.OUT)
GPIO.output(Motor1A,GPIO.LOW)
GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(Motor1B,GPIO.OUT)
GPIO.output(Motor1B,GPIO.HIGH)
GPIO.cleanup()


print "DONE"
