#import libraries
from facelibrary.facedetector import FaceDetector
#import RPi.GPIO as GPIO #import GPIO ports function
import cv2 #import opencv
import time #import time module use for get time, delays and others
import matplotlib #ploting library may be used
import argparse #argument parser for commnad line arguments
import numpy as np
import mahotas
from sklearn.externals import joblib #this library is for character recignition
from num.hog import HOG #data hog library 
from num import dataset #neural network data set
import imutils #created library for basic imageprocessing such as rotation, 
#rezizing and trasnlation, makes it easier to work in case those functions are 
#needed
#this are librarys marcos from the hall and infrared readings
#uncommnet if working in the pi
#from sensor import hall
#from sensor import inred

#contruct my parse
#this parse asks for the video aprameter, no need to feel it in terminal 
ap = argparse.ArgumentParser()
ap.add_argument("-f", "--face", required = True,
	help = "path to where the face cascade resides")
ap.add_argument("-m", "--model", required = True,
	help = "path to where the model will be stored")
ap.add_argument("-v", "--video",
	help = "path to the (optional) video file")
args = vars(ap.parse_args())

# construct the face detector
fd = FaceDetector(args["face"])

# load the model
model = joblib.load(args["model"])

# initialize the HOG descriptor
hog = HOG(orientations = 18, pixelsPerCell = (10, 10),
	cellsPerBlock = (1, 1), transform = True)


#camera for video, condition to call the video for the camrra using arg parses
if not args.get("video", False):
	#default is 0 if using pi camera use 0,otherwise for any usb camera is 1
	camera = cv2.VideoCapture(1) #defines camera one that is not default
#this is used when an specific video is being called	
else:
	camera = cv2.VideoCapture(args["video"])

#temporal variables 
cnt = 0
num_read = 0

#PWM pins
#GPIO.setup(25,GPIO.OUT)
#GPIO.setup(26, GPIO.OUT)
#Trigger pins
#GPIO.output(27, GPIO.OUT)#motor1
#GPIO.output(28, GPIO.OUT)#motor2

#m1 = GPIO.PWM(25,50)
#m1.start(0)
#m2 =  GPIO.PWM(26, 50)
#m2.start




####MAPING LOAD AND SET UP
#defien colors
white = (255,255,255)
red = (0,0,255)
blue = (255,0,0)
green = (0,255,0)
black = (0,0,0)
yellow = (0,255,255)

#load map
map1 = cv2.imread("MAP.png",1)

#uncomment to se map
#cv2.imshow("map",map1)

#define areas 
#they are in parentesis since they will be used as  cordinates
#lab1 (250,90) (460,200)
x = (460-250)/2 + 250
y = (200-90)/2 + 200
lab1 = (x,y)
#exit1lab1 (300,200) (330,210)
x = (330-300)/2 + 300
y = (210-200)/2 + 200
exit1lab1 = (x,y)
#exit2lab1 (440,200) (460,210)
x = (460-440)/2 + 440
y = (210-200)/2 + 200
exit2lab1 = (x,y)

#lab2 (250,330) (460,430)
x = (460-250)/2 + 250
y = (430-330)/2 + 330
lab2 = (x,y)
#exit1lab2 (320,320) (340,330)
x = (340-320)/2 + 320
y = (330-320)/2 + 320
exit1lab2 = (x,y)
#exit2lab2 (420,320) (440,330)
x = (440-420)/2 + 420
y = (330-320)/2 + 320
exit2lab2 = (x,y)

#advising area (70,70) (230,220)
x = (230-70)/2 + 70
y = (220-70)/2 + 70
adv = (x,y)
#advent (230,190) (240,220)
x = (240-230)/2 + 230
y = (220-190)/2 + 190
advent = (x,y)

#mech (100,220) (230,390)
x = (230-100)/2 + 100
y = (390-220)/2 + 220
mech = (x,y)
#mechent (230,230) (240,300)
x = (240-230)/2 + 230
y = (300-230)/2 + 230
mechent = (x,y)

#points to avoid walls
p1 = (380, 260)
p2 = (255, 275)
p3 = (255,205)

#defines the routing posibilities
#no neura network so manual wrriting is needed
def lab1_2_lab2():
	if location_lab1 == 0:
		cv2.line(map1, lab1, exit1lab1,white)
		cv2.line(map1, exit1lab1, exit1lab2, white)
		cv2.line(map1, exit1lab2,lab2,white)
	elif location_lab1 == 1:
		cv2.line(map1, exit1lab1, exit1lab2, white)
		cv2.line(map1, exit1lab2,lab2,white)
	elif location_lab1 == 2:
		cv2.line(map1, exit1lab2,lab2,white)
	elif location_lab1 == 3:
		print "You are here!"
		location_lab1 = 0
	
def lab1_2_mech():
	if location_lab1 == 0:
		cv2.line(map1, lab1, exit1lab1,white)
		cv2.line(map1, exit1lab1, mechent, white)
		cv2.line(map1, mechent, mech,white)
	elif location_lab1 == 1:
		cv2.line(map1, exit1lab1, mechent, white)
		cv2.line(map1, mechent, mech,white)
	elif location_lab1 == 2:
		cv2.line(map1, mechent, mech,white)
	elif location_lab1 == 3:
		print "You are here!"
		location_lab1 = 0

def lab1_2_adv():
	if location_lab1 == 0:
		cv2.line(map1, lab1, exit1lab1, white)
		cv2.line(map1, exit1lab1, mechent, white)
		cv2.line(map1, mechent, advent, white)
		cv2.line(map1, advent, adv, white)
	elif location_lab1 == 1:
		cv2.line(map1, lab1, exit1lab1, white)
		cv2.line(map1, exit1lab1, mechent, white)
		cv2.line(map1, mechent, advent, white)
	elif location_lab1 == 2:
		cv2.line(map1, exit1lab1, mechent, white)
		cv2.line(map1, mechent, advent, white)
	elif location_lab1 == 3:
		cv2.line(map1, mechent, advent, white)
	elif location_lab1 == 4:
		print "You are here!"
		location_lab1 = 0

def lab2_2_lab1():
	if location_lab2 == 0:
		cv2.line(map1, lab2, lab2exit1, white)
		cv2.line(map1, lab2exit1,lab1exit1 ,white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_lab2 == 1:
		cv2.line(map1, lab2exit1,lab1exit1 ,white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_lab2 == 2:
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_lab2 == 3:
		print "You are here!"
		location_lab2 = 0

def lab2_2_mech():
	if location_lab2 == 0:
		cv2.line(map1, lab2, lab2exit1, white)
		cv2.line(map1, lab2exit1,mechent ,white)
		cv2.line(map1, mechent, mech,white)
	elif location_lab2 == 1:
		cv2.line(map1, lab2exit1,mechent ,white)
		cv2.line(map1, mechent, mech,white)
	elif location_lab2 == 2:
		cv2.line(map1, mechent, mech,white)
	elif location_lab2 == 3:
		print "You are here!"
		location_lab2 =0

def lab2_2_adv():
	if location_lab2 == 0:
		cv2.line(map1, lab2, lab2exit1, white)
		cv2.line(map1, lab2exit1, mechent,white)
		cv2.line(map1, mechent, advent, white)
		cv2.line(map1, advent, adv, white)
	elif location_lab2 == 1:
		cv2.line(map1, lab2exit1, mechent,white)
		cv2.line(map1, mechent, advent, white)
		cv2.line(map1, advent, adv, white)
	elif location_lab2 == 2:
		cv2.line(map1, mechent, advent, white)
		cv2.line(map1, advent, adv, white)
	elif location_lab2 == 3:
		cv2.line(map1, advent, adv, white)
	elif location_lab2 == 4:
		print "You are here!"
		location_lab2 = 0

def mech_2_lab1():
	if location_mech == 0:
		cv2.line(map1, mech, mechent, white)
		cv2.line(map1, mechent, lab1exit1, white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_mech == 1:
		cv2.line(map1, mechent, lab1exit1, white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_mech == 2:
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_mech == 3:
		print "You are here!"
		location_mech = 0

def mech_2_lab2():
	if location_mech == 0:
		cv2.line(map1, mech,mechent,white)
		cv2.line(map1, mechent, lab2exit1,white)
		cv2.line(map1, lab2exit1, lab2, white)
	elif location_mech == 1:
		cv2.line(map1, mechent, lab2exit1,white)
		cv2.line(map1, lab2exit1, lab2, white)
	elif location_mech == 2:
		cv2.line(map1, lab2exit1, lab2, white)
	elif location_mech == 3:
		print "You are here!"
		location_mech = 0
def mech_2_adv():
	if location_mech == 0:
		cv2.line(map1,mech,mechent,white)
		cv2.line(map1,mechent,advent, white)
		cv2.line(map1,advent, adv, white)
	elif location_mech == 1:
		cv2.line(map1,mechent,advent, white)
		cv2.line(map1,advent, adv, white)
	elif location_mech == 2:
		cv2.line(map1,advent, adv, white)
	elif location_mech == 3:
		print "You are here!"
		location_mech = 0

def adv_2_lab1():
	if location_adv == 0:
		cv2.line(map1,adv,advent,white)
		cv2.line(map1,advent,mechent,white)
		cv2.line(map1,mechent, lab1exit1, white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_adv == 2:
		cv2.line(map1,advent,mechent,white)
		cv2.line(map1,mechent, lab1exit1, white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_adv == 3:
		cv2.line(map1,mechent, lab1exit1, white)
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_adv == 4:
		cv2.line(map1, lab1exit1, lab1, white)
	elif location_adv == 5:
		print "You are here!"
		location_adv = 0

def adv_2_lab2():
	if location_adv == 0:
		cv2.line(map1, adv,advent,white)
		cv2.line(map1,advent,mechent,white)
		cv2.line(map1,mechent,lab2exit1,white)
		cv2.line(map1,lab2exit1,lab2, white)
	elif location_adv == 1:
		cv2.line(map1,advent,mechent,white)
		cv2.line(map1,mechent,lab2exit1,white)
		cv2.line(map1,lab2exit1,lab2, white)
	elif location_adv == 2:
		cv2.line(map1,mechent,lab2exit1,white)
		cv2.line(map1,lab2exit1,lab2, white)
	elif location_adv == 3:
		cv2.line(map1,lab2exit1,lab2, white)
	elif location_adv == 4:
		print "You are here!"
		location_adv = 0

def adv_2_mech():
	if location_adv == 0:
		cv2.line(map1,adv,advent,white)
		cv2.line(map1,advent,mechent,white)
		cv2.line(map1,mechent,mech,white)
	elif location_adv == 1:
		cv2.line(map1,advent,mechent,white)
		cv2.line(map1,mechent,mech,white)
	elif location_adv == 2:
		cv2.line(map1,mechent,mech,white)
	elif location_adv == 3:
		print "You are here!"
		location_adv = 0




#main program srarts here. While loop is used for simple endless loop
#Main sections: Camera, face, number, localization, sensors
while True:

	#This starts the camera captures
	#grab the current frame
	(grabbed, frame) = camera.read()

	#in case no framed was catch. This may happend while the camera warms up
	#to avoid errors in case the camera is not ready
	if args.get("video") and not grabbed:
		break
	frame = imutils.resize(frame, width = 300)#rezise image makes 
	#processing faster
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	########face recognition##########
	# detect faces in the image and then clone the frame
	# so that we can draw on it
	faceRects = fd.detect(gray, scaleFactor = 1.1, minNeighbors = 5,
		minSize = (30, 30))
	frameClone = frame.copy()

	# loop over the face bounding boxes and draw them detect as many as it 
	# can
	for (fX, fY, fW, fH) in faceRects:
		cv2.rectangle(frameClone, (fX, fY), (fX + fW, fY + fH), 
			(0, 255, 0), 2)
		cnt = cnt + 1 #keeps counts of faces and loops

	# show our detected faces
	cv2.imshow("Face", frameClone)
	print "faces: %i" %cnt

	###########Start number recognition if there is any########


	# blur the image, find edges, and then find contours along
	# the edged regions
	blurred = cv2.GaussianBlur(gray, (5, 5), 0)
	edged = cv2.Canny(blurred, 30, 150)
	(_, cnts, _) = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, 
		cv2.CHAIN_APPROX_SIMPLE)

	# sort the contours by their x-axis position, ensuring
	# that we read the numbers from left to right
	cnts = sorted([(c, cv2.boundingRect(c)[0]) for c in cnts], key = lambda 	x: x[1])
	


	#algorithm not perfect tourble with undesire reading 
	#the if statement prevents overreading of numbers or false readings
	# and also errors that can produce a contants error
	#if will trigger anytime needed with a simple change of variable
	#write a trigger condition since random reading will produce errors
	temp = 0
	pos = []
	if num_read == 1:
	# loop over the contours
		for (c, _) in cnts:
			# compute the bounding box for the rectangle
			(x, y, w, h) = cv2.boundingRect(c)
	
			# if the width is at least 7 pixels and the height
			# is at least 20 pixels, the contour is likely a digit
			if w >= 7 and h >= 20:
				# crop the ROI and then threshold the grayscale
				# ROI to reveal the digit
				roi = gray[y:y + h, x:x + w]
				thresh = roi.copy()
				T = mahotas.thresholding.otsu(roi)
				thresh[thresh > T] = 255
				thresh = cv2.bitwise_not(thresh)
		
				# deskew the image center its extent
				thresh = dataset.deskew(thresh, 20)
				thresh = dataset.center_extent(thresh, (20, 20))
	
				cv2.imshow("thresh", thresh)
	
				# extract features from the image and classify 	
				# it
				hist = hog.describe(thresh)
				digit = model.predict([hist])[0]
				
				print("n:{}".format(digit))
	
				# draw a rectangle around the digit, the show 
				#what the
				# digit was classified as
				cv2.rectangle(frame, (x, y), (x + w, y + h),
					(0, 255,0), 1)
				cv2.putText(frame, str(digit), (x - 10, y - 10),
				cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 2)
				cv2.imshow("image", frame)
				
				if temp < 7:
					pos.append(digit)
					temp += 1
				else:
					num_read = 0
	#### localization part, find current possition

		
	
	###driving motor stop
	#if more than two face show than stop
	if cnt >= 1:
		print "stop"
		
	
	

	cnt = 0 #sets the count back to 0
	#breaks of loop if press q
	#stops all the programs
	if cv2.waitKey(1) & 0xFF == ord("q"):
		break

#releases the camera and destroys any remain window
camera.release()
cv2.destroyAllWindows()

	
