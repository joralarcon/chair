#from __future__ import print_function
import cv2
import argparse
import numpy as np
from matplotlib import pyplot as plt
import time




map_floor = cv2.imread("map1.jpg",1)
w = map_floor.shape[1]
h = map_floor.shape[0]

#print(w, h)

cv2.imshow("map", map_floor)

#create lines
i = 0
c = 0
#defien colors
white = (255,255,255)
red = (0,0,255)
blue = (255,0,0)
green = (0,255,0)
black = (0,0,0)
yellow = (0,255,255)
#verticals
#for x in range(0,755,10):
#	if i == 10:
#		cv2.line(map_floor,(x,0),(x,534),red)
#		i = 0
#	else:
#		cv2.line(map_floor,(x,0),(x,534),white)
#		i+= 1
#horizontal
#for y in range(0,535,10):
#	if c == 10:
#		cv2.line(map_floor,(0,y),(755,y),red)
#		c = 0
#	else:
#		cv2.line(map_floor,(0,y),(755,y),white)
#		c+= 1

#eblab1
cv2.rectangle(map_floor,(250,90),(460,200),yellow,-1)
#eblab2
cv2.rectangle(map_floor,(250,330),(460,430),yellow,-1)

#define exits
#EB lab2 exits
cv2.rectangle(map_floor,(320,320),(340,330),blue, -1)
cv2.rectangle(map_floor,(420,320),(440,330),blue, -1)
#EB lab 1 exits
cv2.rectangle(map_floor,(300,200),(330,210),blue, -1)
cv2.rectangle(map_floor,(440,200),(460,210),blue, -1)
#stairs
cv2.rectangle(map_floor,(470,270),(590,300),black, -1)
cv2.rectangle(map_floor,(0,0),(40,110),black, -1)
cv2.rectangle(map_floor,(0,420),(60,490),black, -1)
#red advising area
cv2.rectangle(map_floor,(70,70),(230,220),red,-1)
	#entrnace
cv2.rectangle(map_floor,(230,190),(240,220),blue,-1)
#green mechanical engineering
cv2.rectangle(map_floor,(100,220),(230,390),green,-1)
cv2.rectangle(map_floor,(60,290),(100,390),green,-1)
	#entrance
cv2.rectangle(map_floor,(230,230),(240,300),blue,-1)
#nogo rooms infornt of lab 1
cv2.rectangle(map_floor,(340,200),(430,240),black,-1)






#class rooms
#3.04.06
#cv2.rectangle(map_floor,(70,0),(130,50),yellow,-1) 
	#entance
#cv2.rectangle(map_floor,(110,40),(130,50),blue,-1)
#3.04.08
#cv2.rectangle(map_floor,(130,0),(195,50),yellow,-1) 
	#entance
#cv2.rectangle(map_floor,(180,40),(195,50),blue,-1)
#3.04.10
#cv2.rectangle(map_floor,(195,0),(250,50),yellow,-1) 
	#entance
#cv2.rectangle(map_floor,(200,40),(210,50),blue,-1)
#3.04.12
#cv2.rectangle(map_floor,(250,0),(300,70),yellow,-1) 
	#entance
#cv2.rectangle(map_floor,(260,60),(275,70),blue,-1)


cv2.imshow("map lines", map_floor)
cv2.waitKey(0)

cv2.imwrite("MAP.png",map_floor)
